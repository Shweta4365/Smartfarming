/*
 *
 * Project Name: 	Smart Farming
 * Author List: 		Shweta More
 *
 * Filename: 		MainActivity.java
 * Functions: 		openActivity2(), openactivity1()
 * Global Variables:	None
 *
 */
package com.Shweta.smartapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    public Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Create instance of button to open crop prediction activity
        Button bn = (Button) findViewById(R.id.b2);
        bn.setOnClickListener(new View.OnClickListener() { // On click event
            @Override
            public void onClick(View v) {
                openactivity1(); // open crop prediction activity
            }
        });

        button = (Button) findViewById(R.id.button); // Create instance of button to open parameter viewing activity
        button.setOnClickListener(new View.OnClickListener() { // On click event
            @Override
            public void onClick(View v) {
                openActivity2(); // open parameter viewing activity
            }
        });
    }
    /*
     *
     * Function Name: 	openActivity2
     * Input: 		None
     * Output: 		open parameter viewing activity
     * Logic: 		To open aaa3.java i.e parameter viewing activity by using Intent keyword
     * Example Call:		openActivity2();
     *
     */
    public void openActivity2() {
        Intent intent = new Intent(this,aa3.class);
        startActivity(intent);
    }
    /*
     *
     * Function Name: 	openactivity1
     * Input: 		None
     * Output: 		open crop prediction activity
     * Logic: 		To open a predict.java i.e crop prediction the activity by using Intent keyword
     * Example Call:		openactivity1();
     *
     */
    public void openactivity1() {
        Intent intent = new Intent(this,predict.class);

        startActivity(intent);
    }
}

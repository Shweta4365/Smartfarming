/*
 *
 * Project Name: 	Smart Farming
 * Author List: 	Shweta More
 * Filename: 		predict.java
 * Functions: 		None
 * Global Variables:	None
 *
 */
package com.Shweta.smartapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class predict extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predict);
        final DatabaseReference tr; // Create Database Reference
        tr = FirebaseDatabase.getInstance().getReference();
        tr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String Suitable_Temperature = null;
                String Suitable_Humidity = null;
                String Temperature = dataSnapshot.child("Temp").getValue().toString(); // Online crop prediction in database
                String Humidity = dataSnapshot.child("Humidity").getValue().toString(); // Online crop prediction in database
                int Temperature_Integer = Integer.parseInt(Temperature); // Temperature string converted to integer
                int Humidity_Integer = Integer.parseInt(Humidity); // Humidity string converted to integer
                TextView ty = (TextView) findViewById(R.id.cr); // final Result i.e predicted crop based on parameters
                // selecting character based on temperature range and your temperature
                if(Temperature_Integer>=25 && Temperature_Integer <=30){
                    Suitable_Temperature = "A";
                }
                else if(Temperature_Integer>=31 && Temperature_Integer <=35){
                    Suitable_Humidity = "B";
                }
                // selecting character based on humidity range and your humidity

                if(Humidity_Integer>=50){
                   Suitable_Humidity = "a";
                }
                String p = dataSnapshot.child("crop").child(Suitable_Temperature).child(Suitable_Humidity).getValue().toString(); // selecting the crop based on selected characters
                ty.setText(p);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { // to execute something if database fails

            }
        });

    }
}

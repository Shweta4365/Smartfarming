/*
 *
 * Project Name: 	Smart Farming
 * Author List: 		Shweta More
 * Filename: 		a3.java
 * Functions: 		No functions
 * Global Variables:	None
 *
 */

package com.Shweta.smartapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class a3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a3);
        Intent intent = getIntent();
        String parameter = intent.getStringExtra(aa3.EXTRA_TEXT); // To get Parameter name from previous activity
        String parameter_value = intent.getStringExtra(aa3.EXTRA_NUMBER); // To get Parameter value name from previous activity
        TextView tex = (TextView) findViewById(R.id.textView);
        tex.setText("Today's "+parameter+" is "+parameter_value); // To print the final result
    }
}

/*
 *
 * Project Name: 	Smart Farming
 * Author List: 		Shweta More
 * Filename: 		aa3.java
 * Functions: 		openact(String , String)
 * Global Variables: Temperature_surrounding,External_Humidity,Soil_moisture,PH_Value_of_soil,Air_pollution_reading,EXTRA_TEXT,EXTRA_NUMBER
 *
 */

package com.Shweta.smartapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class aa3 extends AppCompatActivity {

    String Temperature_surrounding,External_Humidity,Soil_moisture,PH_Value_of_soil,Air_pollution_reading; // stings which stores real-time data in form of string

public static final String EXTRA_TEXT ="com.example.application.example.EXTRA_TEXT"; // used to pass string from this activity to other
    public static final String EXTRA_NUMBER ="com.example.application.example.EXTRA_NUMBER"; // used to pass string from this activity to other
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aa3);


        ImageButton tr1 = (ImageButton) findViewById(R.id.ib1); // using a variable to access a button
        tr1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {        // an on click event

                openact(Temperature_surrounding,"Temperature");

            }
        });
        ImageButton tr2 = (ImageButton) findViewById(R.id.ib2); // using a variable to access a button
        tr2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {  // an on click event

                openact(External_Humidity,"Humidity");
            }
        });
        ImageButton tr3 = (ImageButton) findViewById(R.id.ib3); // using a variable to access a button
        tr3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {   // an on click event

                openact(Soil_moisture,"Soil Moisture");
            }
        });
        ImageButton tr4 = (ImageButton) findViewById(R.id.ib4); // using a variable to access a button
        tr4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {    // an on click event

                openact(PH_Value_of_soil,"pH");
            }
        });

        ImageButton tr6 = (ImageButton) findViewById(R.id.ib6); // using a variable to access a button
        tr6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {    // an on click event

                openact(Air_pollution_reading,"Air Pollution ");
            }
        });
        final DatabaseReference ref;  // creating a database reference
        ref = FirebaseDatabase.getInstance().getReference();
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Temperature_surrounding = dataSnapshot.child("Temp").getValue().toString(); // getting realtime data of Temperature from firebase
                External_Humidity = dataSnapshot.child("Humidity").getValue().toString(); // getting realtime data of Humidity from firebase
                Soil_moisture = dataSnapshot.child("Soil Moisture").getValue().toString(); // getting realtime data of Soil Moisture from firebase
                PH_Value_of_soil = dataSnapshot.child("pH").getValue().toString(); // getting realtime data of Soil PH from firebase

                Air_pollution_reading = dataSnapshot.child("Pollution").getValue().toString(); // getting realtime data of Air pollution from firebase
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) { // database error function to cause any action if database fails

            }
        });


    }

    /*
     *
     * Function Name: 	openact
     * Input: 		String r : This input is a String which contains the real-time reading ,
     *              String z : This input is a String which contains the name of that parameter
     * Output: 		opens a new activity when called
     * Logic: 		Gets two input strings the name and value of that parameter and with the help of intent it sends it to the next
     *              activity i.e a3.java and opens that activity
     * Example Call:		openact(parameter_reading,parameter_name)
     *
     */

    public void openact(String r,String z) {
        Intent intent = new Intent(this,a3.class);         intent.putExtra(EXTRA_TEXT,r); // send The string to a3.java activity
        intent.putExtra(EXTRA_NUMBER,z);  // send The string to a3.java activity
        startActivity(intent); // open activity a3.java
    }

}

